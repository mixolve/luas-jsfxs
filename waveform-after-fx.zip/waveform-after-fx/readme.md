custom_check-items-takes.lua you should start with reaper by hands or any other way
custom-cycle_waveform-after-fx.INI this is for importing in cycle actions
just add cycle action to keyboard button or any way you do it
if you reading this you already know how it works, so enjoy!